#Algumas Informações :).

##Spring JPA Setup
Altere **application.properties** e configure o login e password e url do seu database.


  	

