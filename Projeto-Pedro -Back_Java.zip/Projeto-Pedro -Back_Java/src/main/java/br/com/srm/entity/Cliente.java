package br.com.srm.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Basic;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CLIENTE")
public class Cliente implements Serializable {

    @Id
    @Basic(optional = false)
    @Column
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long clienteId;

    @Basic(optional = false)
    @Column
    private String nome;

    @Basic(optional = false)
    @Column
    private BigDecimal vlrSolicitado;

    @Basic(optional = false)
    @Column
    private BigDecimal vlrConcedido;

    @Basic(optional = false)
    @Column
    private String endereco;

    public Cliente() {
    }

    public Long getClienteId() {
        return clienteId;
    }

    public void setClienteId(Long clienteId) {
        this.clienteId = clienteId;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public BigDecimal getVlrSolicitado() {
        return vlrSolicitado;
    }

    public void setVlrSolicitado(BigDecimal vlrSolicitado) {
        this.vlrSolicitado = vlrSolicitado;
    }

    public BigDecimal getVlrConcedido() {
        return vlrConcedido;
    }

    public void setVlrConcedido(BigDecimal vlrConcedido) {
        this.vlrConcedido = vlrConcedido;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    

}
