package br.com.srm.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.srm.entity.Cliente;
import br.com.srm.service.ClienteService;
import br.com.srm.dao.ClienteDAO;



@Service
public class ClienteServiceImpl implements ClienteService {
	
	@Autowired
	private ClienteDAO clientDAO;

	@Transactional
	public void add(Cliente client) {
		clientDAO.add(client);
	}

	@Transactional
	public void edit(Cliente client) {
		clientDAO.edit(client);
	}

	@Transactional
	public void delete(Long clientId) {
		clientDAO.delete(clientId);

	}

	@Transactional
	public Cliente getCliente(Long clientId) {
		return clientDAO.getCliente(clientId);
	}

	@Transactional
	public List<Cliente> getAllCliente() {
		return clientDAO.getAllCliente();
	}

}
