/**
 *
 */
package br.com.srm.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import br.com.srm.entity.Cliente;
import br.com.srm.service.ClienteService;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;

@Controller
public class ClienteController {

    @Autowired
    private ClienteService clientService;

    @RequestMapping("/srm/entrega")
    public String setupForm(Map<String, Object> map) {
        Cliente client = new Cliente();
        map.put("client", client);
      map.put("clientList", clientService.getAllCliente());
        return "client";
    }

    @RequestMapping(value = "/srm/dados", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
    public String doActions(@RequestBody Cliente client, @RequestParam String action) {
        switch (action.toLowerCase()) {
            case "add":
                clientService.add(client);
                break;
            case "edit":
                clientService.edit(client);
                break;
            case "delete":
                clientService.delete(client.getClienteId());
                break;
        }
        return "client";
    }

}
