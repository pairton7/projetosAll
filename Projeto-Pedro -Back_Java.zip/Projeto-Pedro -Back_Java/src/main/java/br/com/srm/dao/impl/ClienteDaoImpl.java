package br.com.srm.dao.impl;

import br.com.srm.dao.ClienteDAO;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import br.com.srm.entity.Cliente;

@Repository
public class ClienteDaoImpl implements ClienteDAO {

    @Autowired
    private SessionFactory session;

    @Override
    public void add(Cliente client) {
        session.getCurrentSession().save(client);
    }

    @Override
    public void edit(Cliente client) {
        session.getCurrentSession().update(client);
    }

    @Override
    public void delete(Long clientId) {
        session.getCurrentSession().delete(getCliente(clientId));
    }

    @Override
    public Cliente getCliente(Long clientId) {
        return (Cliente) session.getCurrentSession().get(Cliente.class, clientId);
    }
    
    @Override
    public List<Cliente> getAllCliente() {
        return session.getCurrentSession().createQuery("from Cliente").list();
    }

}
