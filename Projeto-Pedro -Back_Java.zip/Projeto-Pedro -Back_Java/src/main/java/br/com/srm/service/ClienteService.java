/**
 * 
 */
package br.com.srm.service;

import java.util.List;

import br.com.srm.entity.Cliente;

public interface ClienteService {
	
	public void add(Cliente client);
	public void edit(Cliente client);
	public void delete(Long clientId);
	public Cliente getCliente(Long clientId);
	public List<Cliente> getAllCliente();
	
}
