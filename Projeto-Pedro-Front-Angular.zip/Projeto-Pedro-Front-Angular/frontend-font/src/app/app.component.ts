import { AppService } from './app.service';
import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  submited = 'clear';
  cliente = {
    nome: '',
    limite: 0,
    tipo: 'A'
  };

  // Injeção de dependência do serviço responsável
  // por enviar os dados para o backend
  constructor(private appSrv: AppService) {}

  // Função que é chamada no formulário para enviar os dados
  submit(form) {
    this.submited = 'warn';

    // Chama o serviço que faz a requisição para o servidor
    // E coloca como parâmetro os valores do formulário que
    // Está salvo em um objeto
    console.log(this.cliente);

    // Se houver erro no form ele não faz a requisição
    if (!form.valid) {
      return;
    }

    this.submited = 'success';
    this.appSrv.sendData(form.value)
      .subscribe((data) => {
        console.log(data);
      });
  }

  resetForm (form) {
    form.reset();
    this.submited = 'clear';
    this.cliente.nome = '';
    this.cliente.limite = 0;
    this.cliente.tipo = '';
  }
}
