import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class AppService {
    constructor(private http: Http) { }

    // Função responsável por enviar os dados
    sendData(form: any): Observable<any> {
        // Envia para o back via POST
        return this.http.post('/srm/cliente', form);
    }
}
